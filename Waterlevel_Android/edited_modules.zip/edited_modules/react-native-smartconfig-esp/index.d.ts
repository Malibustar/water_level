declare module 'react-native-smartconfig-esp' {
    function start(config: {
        type: 'esptouch' | 'airkiss',
        ssid: string,
        password: string,
        bssid?: string,
        timeout?: number
        cast: Cast
    }): Promise<string>;

    const enum Cast {
        broadcast = "broadcast",
        multicast = "multicast",
    }

    function stop(): void;
}